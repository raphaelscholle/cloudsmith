void greet(){
   print('Cloudsmith: Be Awesome. Automate Everything.');
}
