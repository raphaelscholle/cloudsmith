import 'output.dart';

void main(List<String> arguments) {
  greet();
}
