#!/usr/bin/env python
from __future__ import print_function, unicode_literals


def be_awesome():
    print("Cloudsmith: Be Awesome. Automate Everything.")
    print()


if __name__ == "__main__":
    be_awesome()
