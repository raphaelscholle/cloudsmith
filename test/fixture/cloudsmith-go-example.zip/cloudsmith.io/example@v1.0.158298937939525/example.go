package example

import (
	"fmt"
)

func Run() {
	fmt.Println("Cloudsmith: Be Awesome. Automate Everything.")
}
