// swift-tools-version: 5.9

import PackageDescription

let package = Package(
    name: "cloudsmith-swift-example",
    dependencies: [],
    targets: [
        .executableTarget(
            name: "cloudsmith-swift-example",
            dependencies: [],
            path: "Sources"
        ),
    ]
)