import Foundation

func main() {
    print("Hello, World!")
}

main()